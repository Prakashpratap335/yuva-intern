# Week 7 – Salon Experiment & Causal Analysis

This folder contains a **synthetic training dataset** and starter deliverables for the salon experiment assignment.

## Files
- `salon_appointments_synthetic_300k.csv` – 300,000 simulated appointment-level records across 22 fictional outlets.
- `Experiment_Design_Document.docx` – A/B test design, metrics, sample-size assumptions, analysis plan and causal assumptions.
- `Salon_Experiment_Causal_Analysis.ipynb` – Python notebook for data checks, A/B comparisons, confidence intervals, DiD and segmentation.
- `One_Page_Decision_Memo.docx` – Decision memo template with evidence and risk sections.

## Important
All records and outcomes are simulated for learning. They are not actual Coimbatore salon records and must not be represented as real experiment results. Validate all assumptions and rerun the analysis on the official dataset before making a GO/NO-GO decision.

## Suggested environment
Python 3.10+; pandas, numpy, scipy, statsmodels, jupyter.
